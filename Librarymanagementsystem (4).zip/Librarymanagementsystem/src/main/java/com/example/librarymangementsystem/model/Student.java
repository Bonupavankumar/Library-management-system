package com.example.librarymangementsystem.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "student")
@Getter
@Setter
@NoArgsConstructor
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="student_name")
	private String student_name;
	@Column(name="student_regno")
	private String student_regno;
	@Column(name="student_password")
	private String student_password;
	@Column(name="student_emailid")
	private String student_emailID;	
	@Column(name="student_phone")
	private String student_phone;
	@Column(name="student_DOB")
	private String student_DOB;
	
	
	

}

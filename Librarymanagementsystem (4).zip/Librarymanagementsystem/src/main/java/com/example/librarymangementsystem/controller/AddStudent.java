package com.example.librarymangementsystem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.librarymangementsystem.exception.ResourceNotFoundException;
import com.example.librarymangementsystem.model.Student;
import com.example.librarymangementsystem.repo.AddStudentRepo;


@CrossOrigin(origins = "http://localhost:3000")


@RestController
//@RequestMapping("/SRP/ADMIN")
public class AddStudent {
	@Autowired
	private AddStudentRepo  addStudentRepo;
	
	
	@GetMapping("/stud")
	public List<Student> getAllStudent(){
		return addStudentRepo.findAll();
	}
	@PostMapping("/stud")
	public Student createStudent(@RequestBody Student student) {
		return addStudentRepo.save(student);
	}


	@PutMapping("/stud/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student student){
		Student Students = addStudentRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Student not exist with id :" + id));
		
		Students.setStudent_name(student.getStudent_name());
		Students.setStudent_regno(student.getStudent_regno());
		Students.setStudent_emailID(student.getStudent_emailID());
		Students.setStudent_DOB(student.getStudent_DOB());
		Students.setStudent_phone(student.getStudent_phone());
		Students.setStudent_password(student.getStudent_password());

		
		Student updatedStudentDetail = addStudentRepo.save(Students);
		return ResponseEntity.ok(updatedStudentDetail);
	}  
	
	
	@GetMapping("/stud/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
		Student student = addStudentRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Student not exist with id :" + id));
		return ResponseEntity.ok(student);
	}
	
	@DeleteMapping("/stud/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteStudent(@PathVariable Long id){
		Student student = addStudentRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Student not exist with id :" + id));
		
		addStudentRepo.delete(student);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	

	

}


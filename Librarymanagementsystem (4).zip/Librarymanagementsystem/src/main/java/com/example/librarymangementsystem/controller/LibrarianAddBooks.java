package com.example.librarymangementsystem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.librarymangementsystem.exception.ResourceNotFoundException;
import com.example.librarymangementsystem.model.BookDetail;
import com.example.librarymangementsystem.repo.BookDetailRepo;
@CrossOrigin(origins = "http://localhost:3000")


@RestController
//@RequestMapping("/SRP/LIBRARIAN")

public class LibrarianAddBooks {
	
	@Autowired
	private BookDetailRepo  BookDetailRepo;
	
	
	@GetMapping("/book")
	public List<BookDetail> getAllBook(){
		return BookDetailRepo.findAll();
	}
	@PostMapping("/book")
	public BookDetail createBook(@RequestBody BookDetail bookDetails) {
		return BookDetailRepo.save(bookDetails);
	}
	

	@PutMapping("/book/{id}")
	public ResponseEntity<BookDetail> updateBook(@PathVariable Long id, @RequestBody BookDetail bookDetails){
		BookDetail bookDetail = BookDetailRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));
		
	    bookDetail.setTitle(bookDetails.getTitle());
		bookDetail.setWriter(bookDetails.getWriter());
        bookDetail.setBookid(bookDetails.getBookid());
        bookDetail.setAvailable(bookDetails.getAvailable());
        bookDetail.setAuthor(bookDetails.getAuthor());
        bookDetail.setCategory(bookDetails.getCategory());
        bookDetail.setIssuedate(bookDetails.getIssuedate());
        bookDetail.setReturndate(bookDetails.getReturndate());

		
		BookDetail updatedbookDetail = BookDetailRepo.save(bookDetail);
		return ResponseEntity.ok(updatedbookDetail);
	}  
	
	@GetMapping("/book/{id}")
	public ResponseEntity<BookDetail> getBookById(@PathVariable Long id) {
		BookDetail bookDetail = BookDetailRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));
		return ResponseEntity.ok(bookDetail);
	}
	
	@DeleteMapping("/book/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteBook(@PathVariable Long id){
		BookDetail bookDetail = BookDetailRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));
		
		BookDetailRepo.delete(bookDetail);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	}


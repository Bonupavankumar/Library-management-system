package com.example.librarymangementsystem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.librarymangementsystem.exception.ResourceNotFoundException;
import com.example.librarymangementsystem.model.Librarian;
import com.example.librarymangementsystem.repo.AddLibrarianRepo;


@CrossOrigin(origins = "http://localhost:3000")


@RestController
//@RequestMapping("/SRP/ADMIN")

public class AddLibrarian {
	
	@Autowired
	private AddLibrarianRepo  addLibrarianRepo;
	
	
	@GetMapping("/librarian")
	public List<Librarian> getAllLibrarian(){
		return addLibrarianRepo.findAll();
	}
	@PostMapping("/librarian")
	public Librarian createLibrarian(@RequestBody Librarian librarian) {
		return addLibrarianRepo.save(librarian);
	}


	@PutMapping("/librarian/{id}")
	public ResponseEntity<Librarian> updateLibrarian(@PathVariable Long id, @RequestBody Librarian librarian){
		Librarian librarian2 = addLibrarianRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Librarian not exist with id :" + id));
		
//		librarian.setLibrarian_name(librarian.getLibrarian_name());
//		librarian.setLibrarian_emailID(librarian.getLibrarian_emailID());
//		librarian.setLibrarian_emailID(librarian.getLibrarian_emailID());
//		librarian.setLibrarian_emailID(librarian.getLibrarian_emailID());
        
		
		Librarian updatedlibrarianDetail = addLibrarianRepo.save(librarian);
		return ResponseEntity.ok(updatedlibrarianDetail);
	}  
	
	
	@GetMapping("/librarian/{id}")
	public ResponseEntity<Librarian> getLibrarianById(@PathVariable Long id) {
		Librarian librarian = addLibrarianRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Librarian not exist with id :" + id));
		return ResponseEntity.ok(librarian);
	}
	
	@DeleteMapping("/librarian/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteLibrarian(@PathVariable Long id){
		Librarian librarian = addLibrarianRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Librarian not exist with id :" + id));
		
		addLibrarianRepo.delete(librarian);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	

	

}

package com.example.librarymangementsystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Entity
@Table(name = "bookdetail")
@Getter
@Setter
@NoArgsConstructor

public class BookDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name="title")
	private String title;	
	@Column(name="writer")
	private String writer;	
	@Column(name="bookid")
	private String bookid;
	@Column(name="available")
	private String available;
	@Column(name="author")
	private int author;
	@Column(name="category")
	private String category;
	@Column(name="issuedate")
	private String issuedate;
	@Column(name="returndate")
	private String returndate;
}

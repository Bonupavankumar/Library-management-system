package com.example.librarymangementsystem.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.librarymangementsystem.model.BookDetail;


public interface BookDetailRepo extends JpaRepository<BookDetail, Long> {

}


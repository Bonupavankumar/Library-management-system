package com.example.librarymangementsystem.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.librarymangementsystem.model.Student;

public interface AddStudentRepo extends JpaRepository<Student, Long> {

}

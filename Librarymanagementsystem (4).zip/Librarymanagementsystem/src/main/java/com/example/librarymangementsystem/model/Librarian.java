package com.example.librarymangementsystem.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Librarian")
@Getter
@Setter
@NoArgsConstructor
public class Librarian {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="librarian_name")
	private String librarian_name;
	@Column(name="librarian_password")
	private String librarian_password;
	@Column(name="librarian_emailid")
	private String librarian_emailID;	
	@Column(name="librarian_phone")
	private String librarian_phone;
}

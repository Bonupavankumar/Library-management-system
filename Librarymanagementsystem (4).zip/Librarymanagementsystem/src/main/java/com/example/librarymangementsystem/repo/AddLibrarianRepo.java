package com.example.librarymangementsystem.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.librarymangementsystem.model.Librarian;

public interface AddLibrarianRepo extends JpaRepository<Librarian, Long> {

}
